#include <iostream>
using namespace std;

//

int main()
{
	int a = 1;
	float f = 1.5f;
	double d = 1.5;
	bool isDead = false;
	string name = "�ʷϸŽ�";


	return 0;
}